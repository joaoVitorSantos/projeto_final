<!DOCTYPE html>
<html>
<head>
    <title>GT</title>
    <!-- ViewPort -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <!-- Meu CSS -->
    <link href="assets/css/mycss.css" rel="stylesheet" media="screen">
    <!-- CSS Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
</head>
<body>

<!--menu-->
<div id="menu_index">
    <?php require_once "assets/vendor/navbar.php"; ?>
</div>

<div class="container hidden-xs containerExtra"></div>
<div class="container" id="containerPe">

    <div class="form_group row">
        <div class="col-lg-12 col-md-12 col-xs-12 formPe">
            <?php include 'assets/vendor/formpesquisar.php'; ?>
            <div class="col-md-6"><input id="botaoPesquisar" type="submit" value="Pesquisar" class="btn-success"></div>
        </div>
    </div>
</div>
<!--rodape-->
<?php require_once "assets/vendor/rodape.php"; ?>
</body>
</html>