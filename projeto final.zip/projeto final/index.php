<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
    <head>
        <title>GT</title>
        <!-- ViewPort -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="utf-8">
        <!-- Meu CSS -->
        <link href="assets/css/mycss.css" rel="stylesheet" media="screen">
        <!-- CSS Bootstrap -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
    </head>
<body id="bodyIndex">

    <!--menu-->
    <div id="menu_index">
    <?php require_once "assets/vendor/navbar.php"; ?>
    </div>

    <!--imagem-->

    <div class="cabecalho col-lg-12 col-md-12 col-sm-12">
        <h1 id="slogan_index">CRIE E GERENCIE SEUS TORNEIOS</h1>
    </div>

    <!--container-->
        <div class="container hidden-xs containerExtra"></div>
        <div class="container" id="containerIn">





            <div id="funcionalidades" class="col-md-12 col-lg-12 col-sm-12">
                <a href="criar_torneio.php"><button class="primeiro_icone icones btn btn-default col-md-2 col-lg-3 col-sm-2">
                    Crie torneios <span class="glyphicon glyphicon-plus"></span>
                   </button>
                </a>

                <a href="pesquisar.php" <button id="icone_central_index" class="icones btn btn-default col-md-2 col-lg-3 col-sm-2">
                    Proucure torneios <span class="glyphicon glyphicon-search"></span>
                </button>
            </a>

                <button class="icones btn btn-default col-md-2 col-lg-3 col-sm-2">
                    Rankings <span class="glyphicon glyphicon-globe"></span>
                </button>
            </div>


        </div>





        <!--rodape-->
        <?php require_once "assets/vendor/rodape.php"; ?>

</body>
