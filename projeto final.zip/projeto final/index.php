<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/html">
    <head>
        <title>GT</title>
        <!-- ViewPort -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="utf-8">
        <!-- Meu CSS -->
        <link href="assets/css/mycss.css" rel="stylesheet" media="screen">
        <!-- CSS Bootstrap -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
    </head>
<body id="bodyIndex">

    <!--menu-->
    <div id="menu_index">
    <?php require_once "assets/vendor/navbar.php"; ?>
    </div>

    <!--imagem-->

    <div class="cabecalho col-lg-12 col-md-12 col-sm-12">
        <h1 id="slogan_index">CRIE E GERENCIE SEUS TORNEIOS</h1>
    </div>

    <!--container-->
        <div class="container hidden-xs containerExtra"></div>
        <div class="container" id="containerIn">

            <div class="col-lg-12">
            <a href="criar_torneio.php" class="col-lg-6">
                <button class="botao_index btn-success">Criar Torneio</button>
            </a>
            <a href="pesquisar.php" class="col-lg-6">
                <button class="botao_index btn-warning">Pesquisar</button>
            </a>
            </div>

        </div>





        <!--rodape-->
        <?php require_once "assets/vendor/rodape.php"; ?>

</body>
