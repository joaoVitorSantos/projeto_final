<!DOCTYPE html>
<html>
<head>
    <title>GT</title>
    <!-- ViewPort -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <!-- Meu CSS -->
    <link href="assets/css/mycss.css" rel="stylesheet" media="screen">
    <!-- CSS Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
</head>
<body id="bodyIndex">



<!-- menu -->
<?php require_once "assets/vendor/navbar.php"?>


        <div class="container hidden-xs containerExtra"></div>
        <div class="container" id="containerInn">
            <div id="geral" class="col-md-12 col-sm-12 col-lg-12">

                <table id="tabela" class="col-md-8 col-sm-8 col-lg-8 table">
                    <thead>
                    <tr id="topicos">
                        <th>Classificação</th>
                        <th>Time</th>
                        <th>Jogos</th>
                        <th>Pontos</th>
                        <th>Vitórias</th>
                        <th>Empates</th>
                        <th>Derrotas</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr  class="classificados">
                        <th scope="row">1</th>
                        <td>JEC</td>
                        <td>20</td>
                        <td>60</td>
                        <td>20</td>
                        <td>0</td>
                        <td>0</td>
                    </tr>
                    <tr class="repescagem">
                        <th scope="row">2</th>
                        <td>Avaí</td>
                        <td>20</td>
                        <td>57</td>
                        <td>19</td>
                        <td>0</td>
                        <td>0</td>
                    </tr>
                    <tr class="eliminados">
                        <th scope="row">3</th>
                        <td>Figueirense</td>
                        <td>20</td>
                        <td>20</td>
                        <td>6</td>
                        <td>2</td>
                        <td>12</td>
                    </tr>
                    </tbody>
                </table>

                <div id="partidas" class="col-lg-4 col-sm-4">
                    <p id="titulo_partidas">Partidas</p>

                    <hr>

                    <p class="partidas"> JEC <input class="placar_mandante"> X <input class="placar_visitante"> AVA</p>

                    <hr>

                    <p class="partidas"> FIG <input class="placar_mandante"> X <input class="placar_visitante"> JEC</p>

                    <hr>

                    <p class="partidas"> AVA <input class="placar_mandante"> X <input class="placar_visitante"> FIG</p>


                </div>
            </div>


        </div>





<!--rodapé-->
<?php require_once "assets/vendor/rodape.php"?>



</body>
