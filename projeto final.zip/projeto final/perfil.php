<!DOCTYPE html>
<html>
<head>
    <title>GT</title>
    <!-- ViewPort -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <!-- Meu CSS -->
    <link href="assets/css/mycss.css" rel="stylesheet" media="screen">
    <!-- CSS Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
</head>
<body id="bodyIndex">


    <!--menu-->
    <?php require_once "assets/vendor/navbar.php"?>

    <!--container-->
    <div class="container hidden-xs containerExtra"></div>
    <div class="container" id="containerIn">

        <div id="perfil" class="col-sm-7 col-md-7 col-lg-7">

            <div id="foto_perfil" class="col-sm-5 col-md-5 col-lg-5">

                <img src="assets/imagens/foto_perfil.jpg" class="img-circle">

            </div>

            <div id="dados_perfil" class="col-sm-7 col-md-7 col-lg-7">

                <p class="titulo_atributos">. Nome:</p>
                <p class="atributos">Neymar Jr(NeyJr);</p>

                <br>

                <p class="titulo_atributos">. Modalidade Favorita:</p>
                <p class="atributos"> Vôlei;</p>

                <div class="trofeus col-sm-12 col-md-12 col-lg-12">

                    <div id="1lugar" class="col-sm-4 col-md-4 col-lg-4">
                        <img src="assets/imagens/trofeu_ouro.png">
                    </div>

                    <div id="2lugar" class="col-sm-4 col-md-4 col-lg-4">
                        <img src="assets/imagens/trofeu_prata.png">
                    </div>

                    <div id="3lugar" class="col-sm-4 col-md-4 col-lg-4">
                        <img src="assets/imagens/trofeu_bronze.png">
                    </div>



                </div>

            </div>



        </div>







    </div>

    <!--rodapé-->
    <?php require_once "assets/vendor/rodape.php"?>



</body>
</html>