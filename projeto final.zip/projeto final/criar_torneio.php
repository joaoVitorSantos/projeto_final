<!DOCTYPE html>
<html>
<head>
    <title>GT</title>
    <!-- ViewPort -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <!-- Meu CSS -->
    <link href="assets/css/mycss.css" rel="stylesheet" media="screen">
    <!-- CSS Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
</head>
<body id="bodyIndex">

    <!--menu-->
    <?php require_once "assets/vendor/navbar.php" ?>

    <div class="formulario_criar_torneio jumbotron">
        <label class="titulo_selecao">Selecione a modalidade</label>
        <select class="selecao">
            <option>Esporte</option>
            <option>E-Sport</option>
        </select>

        <hr>

        <label class="titulo_selecao">Selecione a categoria</label>
        <select class="selecao">
            <option>Futebol</option>
            <option>Lol</option>
        </select>

        <hr>

        <label class="titulo_selecao">Digite o número de participantes</label>
        <br>

        <input type="number" class="selecao">

        <hr>

        <label class="titulo_selecao">Selecione o formato do torneio</label>
        <select class="selecao">
            <option>Liga</option>
            <option>Grupos e mata-mata</option>
            <option>Mata-mata</option>
        </select>
        
        <hr>

        <a href="torneio.php"><button id="botao_criacao" type="button" class="botoes_menu btn btn-info">Criar Torneio</button></a>

    </div>


    <!--rodape-->
    <?php require_once "assets/vendor/rodape.php"?>

</body>
</html>


