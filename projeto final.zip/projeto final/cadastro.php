<!DOCTYPE html>
<html>
    <head>
        <title>GT</title>
        <!-- ViewPort -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="utf-8">
        <!-- Meu CSS -->
        <link href="assets/css/mycss.css" rel="stylesheet" media="screen">
        <!-- CSS Bootstrap -->
        <link href="assets/css/bootstrap.min.css" rel="stylesheet" media="screen">
    </head>
   <body id="bodyIndex">
   <!-- NavBar -->
   <?php include 'assets/vendor/navbar.php' ?>
    <!-- Body-->


   <div class="container hidden-xs containerExtra"></div>
   <div class="container" id="containerIn">

       <div class="form_group row">
           <div class="col-lg-12 col-md-12 col-xs-12 formIn">
               <?php include 'assets/vendor/formcadastrar.php'; ?>

       </div>
       </div>
   </div>




   <footer class="footer">
       <div class="container">
           <p class="logo_rodape text-muted">GT</p>
       </div>
   </footer>


   <script src="assets/js/jquery-3.2.1.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/main.js"></script>

    </body>
</html>